# MazeGroup.py
MazeGroup.py is an general prupose library for Python.

[GitHub](https://github.com/Geniusum/mazegroup.py)
[MazeGroup](https://mazegroup.org/)