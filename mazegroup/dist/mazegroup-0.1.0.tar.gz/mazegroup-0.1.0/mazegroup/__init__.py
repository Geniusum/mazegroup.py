"""
# MazeGroup.py
MazeGroup.py is an general prupose library for Python.
"""